package tikTat.dennis;

import java.io.FileWriter;

public class ScoreCounter {

        // speicherung der Gewinndaten. Mit FileWriter eine externe Datei auslagern
        // zählung der ScoreDaten durch ein Array, dann vergleichen mit der anzahl der spielzüge und die differenz wischen
        // zwei Spielern berechnen
        //
        // ScoreDaten terminieren - Spielzüge einstellen
        // Ausgabe der Score daten am Ende


}
