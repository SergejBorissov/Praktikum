package com.ablex.view;

import javafx.scene.layout.Pane;

public class MainFrame {

    private MainFrameController mainFrameController;
    private Pane rootPane;



    MainFrame(MainFrameController mainFrameController, Pane rootPane){
        this.mainFrameController = mainFrameController;

        this.rootPane = rootPane;
    }

    public MainFrameController getMainFrameController() {
        return mainFrameController;
    }

    public Pane getRootPane() {
        return rootPane;
    }
}
