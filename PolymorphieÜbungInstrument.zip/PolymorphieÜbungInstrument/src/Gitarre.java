public class Gitarre extends Klangmittel implements Stimmgerät, Effektgerät{
    public void gitarrenRiff(){
        System.out.println("Metal-Riff");
    }
    @Override
    public void erklingen(){
        gitarrenRiff();

    }

    @Override
    public void macheEffekt() {

    }
}
