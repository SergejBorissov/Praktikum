package JustDoIt;


import java.util.Random;

public class ZufallGenerator {

    public static void main(String[] args) {

        int[] zufallFeld =  new int[2];

        Random wuerfel = new Random();
        int buttonNummer;

        for (int i=0; i<3; i++){
            buttonNummer = 1 + wuerfel.nextInt(8);
            System.out.println(buttonNummer);
            }
        }

}


