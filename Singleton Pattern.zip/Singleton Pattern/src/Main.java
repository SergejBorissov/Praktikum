public class Main {

    public static void main(String[] args) {
        Sonne sonne = Sonne.getInstance();

        System.out.println("Die geschätzte Dichte der Sonnne liegt bei: " +
                sonne.getDichte() + " g/cm³ ");
    }
}
