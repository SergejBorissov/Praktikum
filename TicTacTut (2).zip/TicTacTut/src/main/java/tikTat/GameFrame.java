package tikTat;

import javafx.application.Application;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Screen;
import javafx.stage.Stage;



public class GameFrame extends Application {


    @Override
    public void start(Stage primaryStage) throws Exception {


        GameField gameField = new GameField();
        BorderPane root = new BorderPane();
        root.setCenter(gameField);

        Screen screen = Screen.getPrimary();
        Rectangle2D bounds = screen.getVisualBounds();
        primaryStage.setX(bounds.getMinX());
        primaryStage.setY(bounds.getMinY());

       // primaryStage.setWidth(bounds.getWidth());
        //primaryStage.setHeight(bounds.getHeight());

        Scene scene = new Scene(root, 750,750);
        primaryStage.setTitle("TikTakVersion4");
        scene.getStylesheets().add(getClass().getResource("designButtons.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();

    }
}
