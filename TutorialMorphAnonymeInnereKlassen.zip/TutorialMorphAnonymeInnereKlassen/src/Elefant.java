public class Elefant extends Tier
{


    public int alter = 120;

    @Override
    public void macheDichBemerkbar()
    {
        System.out.println("Tarüüüüüüüüüü");
    }


    @Override
    public int getAlter()
    {
        System.out.println("alter vom ELefeanter: ");
        return this.alter;
    }

    @Override
    public void doSomething(int i)
    {
        System.out.println("blubb");
        if(i == 0)
        {
            return;
        }
        super.doSomething(i);
    }
}
