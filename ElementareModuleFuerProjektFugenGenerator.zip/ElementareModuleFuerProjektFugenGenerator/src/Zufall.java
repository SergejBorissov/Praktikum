import java.util.Arrays;
import java.util.Random;

public class Zufall {

    public static void main(String[] args) {

        /* double[] randoms = new double[10];
        Arrays.setAll(randoms, value -> Math.random());
        System.out.println(Arrays.toString(randoms));
         */

        int zufallZahl;

        Random random = new Random();

        zufallZahl = random.nextInt(121);

        int[] zahlenArray = new int[5];

        Arrays.fill(zahlenArray, zufallZahl);
        System.out.println(Arrays.toString(zahlenArray));
        System.out.println("inhalt auf indexnr: " +  zahlenArray[3]);
    }
}
