package data;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringIndexOfArrayIterator {


    public static void main(String[] args) {

        StringBuilder tagsKette = new StringBuilder("<Name>Anselm</Name><Nachname>Kiefer</Nachname>");



        //Durchiterieren des String, um alle char elemente zu findne
        // und jeweils jedem gefundenem Char element, einen atomaren index zu geben
        // dann alle startIndexe und endIndexe lokalisieren und jeweils alle Inhalte ausgeben


        int startIndex = tagsKette.indexOf(">");




        System.out.println(startIndex);

    }
}
