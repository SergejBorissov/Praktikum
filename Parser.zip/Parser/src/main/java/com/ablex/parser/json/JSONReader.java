package com.ablex.parser.json;

import com.ablex.parser.DataReader;

public class JSONReader implements DataReader
{
    private String fileName;


    @Override
    public void readData(String fileName) {

    }
}
