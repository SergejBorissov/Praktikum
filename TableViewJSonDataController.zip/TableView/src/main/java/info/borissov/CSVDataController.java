package info.borissov;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class CSVDataController implements DataController{


    @Override
    public List<Person> readData(String filename) {
        List<Person> data = new ArrayList<>();

        String fieldDelimiter = ",";

        BufferedReader br;

        try {
            br = new BufferedReader(new FileReader(filename));

            String line;
            while ((line = br.readLine()) != null) {
                String[] fields = line.split(fieldDelimiter, -1);

                if (fields.length >= 6) {
                    Person record = new Person(fields[0], fields[1], fields[2],
                            fields[3], fields[4], fields[5]);
                    data.add(record);
                }

            }
            Thread.sleep(1000);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName())
                    .log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName())
                    .log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName())
                .log(Level.SEVERE, "sleep", ex);
        }

        return data;
    }
}
