public class Sub extends Super {

    final int a = 5;

    static
    {
        System.out.println("Sub Static Initializer");
    }

    //Wird jedes mal aufgerufen
    {
        System.out.println("Sub Instance Initializer");
        methodeSprich();
    }


    public Sub()
    {
        String x;
        System.out.println("Sub Constructor");
    }

    public Sub(int i)
    {
        System.out.println("Sub Konstruktor with param");
    }

    public static void main(String[] args)
    {
        new Sub();
        new Sub(1);
    }

    private void methodeSprich()
    {
        System.out.println("Sub-Methode  " + a);
        System.out.println("ausgabe konstante zahl: " + zahlX);
    }
}
