public class Hund extends Tier
{
    public double gewicht = 45;
    public int alter = 10;
    @Override
    public void macheDichBemerkbar()
    {
        int alterVonSuper = super.getAlter();
        System.out.println(super.alter);
        super.macheDichBemerkbar();
        System.out.println("Wuff");
    }

    @Override
    public int getAlter()
    {
        System.out.println("Alter vom Hund: ");
        return this.alter;
    }
}
