package tikTat.dennis;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class Player {

    private StringProperty nameProperty = new SimpleStringProperty();

    private GameIconFactory gameIconFactory;

    public Player(String name, GameIconFactory gameIconFactory) {
        this.nameProperty.set(name);
        this.gameIconFactory = gameIconFactory;
    }

    public StringProperty nameProperty() {
        return nameProperty;
    }

    public GameIconFactory getGameIconFactory() {
        return gameIconFactory;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Player)) return false;

        Player player = (Player) o;

        return nameProperty.get().equals(player.nameProperty.get());
    }

    @Override
    public int hashCode() {
        return nameProperty.get().hashCode();
    }

    @Override
    public String toString() {
        return nameProperty.get();
    }
}
