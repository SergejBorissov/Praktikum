public class Super {

    int a = 123;
    double zahlX = 2.234544345434;

    static
    {
        System.out.println("Super Static Initializer");
    }

    //Wird jedes mal aufgerufen
    {
        System.out.println("Super Instance Initializer");
        methodeSprich();
    }


    public Super()
    {
        System.out.println("Super Constructor");
    }
    public Super(int i)
    {
        System.out.println("Super Konstruktor with param");
    }
    private void methodeSprich(){
        System.out.println("Super MEthode  " + a);
    }
}
