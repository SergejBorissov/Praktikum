package tikTat.dennis;

import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import static javafx.geometry.Pos.CENTER;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class GameField extends VBox {

    private GridPane gridPane = new GridPane();
    private Button buttonMainMenu = new Button("Zurück ins Hauptmenü");
    private Button buttonExit = new Button("Spiel beenden");

    private GameController gameController;
    private int gameFieldSize;

    private Runnable runnableBackToMainMenu;
    private Runnable runnableGameExit;

    public GameField(int gameFieldSize, GameController gameController) {
        this.gameFieldSize = gameFieldSize;
        this.gameController = gameController;
        this.gameController.setGameFieldSize(gameFieldSize);

        initButtons();
        initPane();
    }

    public void setRunnableBackToMainMenu(Runnable runnableBackToMainMenu) {
        this.runnableBackToMainMenu = runnableBackToMainMenu;


    }
    public void setRunnableGameExit(Runnable runnableGameExit){
        this.runnableGameExit = runnableGameExit;
    }


    public void startGame(Stage stage) {

        Player nextPlayer = gameController.getNextPlayer();

    }

    private void initPane() {
        for (int x = 0; x < gameFieldSize; x++) {
            for (int y = 0; y < gameFieldSize; y++) {
                gridPane.add(buildPlayableField(x, y), x, y);
                gridPane.setAlignment(CENTER);


            }
        }

        this.getChildren().addAll(gridPane, buttonMainMenu, buttonExit);

    }

    private PlayableField buildPlayableField(int x, int y) {
        PlayableField playableField = new PlayableField(gameController, x, y);

        return playableField;
    }


    private void initButtons() {

        buttonMainMenu.setOnAction(event -> backToMainMenu());




        buttonExit.setOnAction(event -> gameExit());
    }

    private void backToMainMenu() {

        runnableBackToMainMenu.run();

    }

    private void gameExit(){
        runnableGameExit.run();
    }
}

