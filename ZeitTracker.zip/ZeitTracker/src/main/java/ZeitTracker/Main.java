package ZeitTracker;

/**@author: Sergej Borissov
 * @version: 0.0.0.1
 *
 * @task: timer
 */

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Stream;


public class Main
{




    public static void main(String[] args)
    {


        Timer timer = new Timer();

        LocalDate localDate = LocalDate.now();
        LocalTime localTime = LocalTime.now();
        LocalDateTime localDateTime = LocalDateTime.now();

        //System.out.println("Gegenwärtiges Datum:   " + localDate.toString());
        System.out.println("Gegenwärtige Zeit:  " +  localTime.toString());
        Stream.of("lOCALdATE: " + localDate, "localTIME:  " + localTime, "LcalDateAndTime:  " + localDateTime).limit(3).forEach(System.out::println);



        new Thread()
        {
            @Override
            public void run()
            {

                for(int i = 0; i < 3; i++) {

                    new Timer().schedule( new LambdaTimerTask( () -> System.out.println("1\t"+LocalTime.now().toString()) ), 500 );
                    try {
                        Thread.sleep(2000);

                    }

                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }


        }.start();
        new Thread()
        {
            @Override
            public void run()
            {

                for(int i = 0; i < 3; i++) {

                    new Timer().schedule( new LambdaTimerTask( () -> System.out.println("2\t"+LocalTime.now().toString()) ), 500 );
                    try {
                        Thread.sleep(2000);

                    }

                    catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }


        }.start();

    }

}
