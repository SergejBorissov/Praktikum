package info.borissov;

import java.util.Arrays;
import java.util.List;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class JSONDataController implements DataController{

    @Override
    public List<Person> readData(String filename) {
        return Arrays.asList(new Person("1", "1", "1", "1", "1", "1"),
                new Person("2", "2", "2", "2", "2", "2"),
                new Person("4", "4", "3", "3", "3", "3"));

    }
}
