package tikTat.dennis;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class TicTacToeApplication extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        GameController gameController = new GameController();

        gameController.playerWon().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                System.out.println("player " + newValue.toString() + " has won");
            }
        });

        gameController.registerPlayer1(new Player("Player 1", () -> new GameIcon("X")));
        gameController.registerPlayer2(new Player("Player 2", () -> new GameIcon("O")));

        GameField gameField = new GameField(5, gameController);
        primaryStage.setScene(new Scene(gameField));
        primaryStage.getScene().getStylesheets().add(getClass().getResource("design.css").toExternalForm());

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
