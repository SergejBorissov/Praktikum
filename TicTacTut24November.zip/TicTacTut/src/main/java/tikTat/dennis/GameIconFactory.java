package tikTat.dennis;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
@FunctionalInterface
public interface GameIconFactory {

    public GameIcon buildGameIcon();
}
