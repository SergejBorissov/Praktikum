package com.ablex;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Callback;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {

        TableView tableView = new TableView();
        TableColumn firstName = new TableColumn("Vorname");
        TableColumn lastName = new TableColumn("Nachname");
        TableColumn goals = new TableColumn("Tore");
        tableView.getColumns().addAll(firstName, lastName, goals);


        ObservableList<Player> players = FXCollections.observableArrayList(
                new Player("Manuel", "Neuer", 0),
                new Player("Phillip", "Lahm", 0),
                new Player("Mats", "Hummels", 2),
                new Player("Jerome", "Boateng", 0),
                new Player("Benedikt", "Höwedes",0)
        );


        firstName.setCellFactory(
                new PropertyValueFactory<Player, String>("firstName")
        );

        lastName.setCellFactory(
                new PropertyValueFactory<Player, String>("lastName")
        );
        goals.setCellFactory(
                new PropertyValueFactory<Player, String>("goals")
        );

        goals.setCellFactory(new Callback<TableColumn< Player, Integer>,
                TableCell<Player, Integer>>(){
            @Override
            public TableCell<Player, Integer> call(TableColumn<Player,
                    Integer> param){
                return new GoalsCell();
            }
        });

        tableView.setItems(players);
        StackPane root = new StackPane(tableView);
        Scene scene = new Scene(root, 300,250);

        primaryStage.setTitle("Versuch Nr.1: TableView mit CSV Parser");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
