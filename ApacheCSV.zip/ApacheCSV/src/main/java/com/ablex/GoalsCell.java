package com.ablex;

import javafx.scene.control.TableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

public static class GoalsCell extends TableCell<Player, Integer> {

    private final HBox goalsBox;
    private final Image goalImage;

    public GoalsCell(){
        goalsBox = new HBox();
        goalImage = new Image(GoalsCell.class.getResource("ball.png").toString()
        );
    }

    @Override

    protected void updateItem(Integer item, boolean empty){

        setText("");
        goalsBox.getChildren().clear();
        if(item != null){
            for (int i = 0; i < item; i++){
                goalsBox.getChildren().add(new ImageView(goalImage));
            }
        }
        setGraphic(goalsBox);
    }

}


