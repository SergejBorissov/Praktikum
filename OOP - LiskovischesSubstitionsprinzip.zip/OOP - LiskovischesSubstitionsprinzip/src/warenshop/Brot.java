package warenshop;



public class Brot extends Lebensmittel{

    protected boolean geschnitten;


    public Brot(){
        this.bezeichnung = "Brot";
        this.artikelnummer = 22;
        this.preis = 5;
        this.geschnitten = true;
        // this.haltbarkeitsdatum = 21.12.1998;
    }

}
