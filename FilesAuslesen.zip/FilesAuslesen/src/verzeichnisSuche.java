

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class verzeichnisSuche {


    public static void main(String[] args) {



        public ArrayList<File> searchFile (File dir, String find){

            File[] files = dir.listFiles();
            ArrayList<File> matches = new ArrayList<File>();
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    if (files[i].getName().equalsIgnoreCase(find)) {
                        matches.add(files[i]);
                    }
                    if (files[i].isDirectory()) {
                        matches.addAll(searchFile(files[i], find));
                    }
                }
            }
            return matches;
        }

        public void listDir (File dir){

            File[] files = dir.listFiles();
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    System.out.print(files[i].getAbsolutePath());
                    if (files[i].isDirectory()) {
                        System.out.print(" (Ordner)\n");
                        listDir(files[i]);
                    } else {
                        System.out.print(" (Datei)\n");
                    }
                }
            }
        }


    }
}

