abstract class Klangmittel {
  static int kammerton = 440;

  public abstract void erklingen();
  public void gibTonHoehe(){
    System.out.println(kammerton);
  }

}
