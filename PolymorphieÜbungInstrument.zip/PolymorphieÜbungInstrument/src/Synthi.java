public class Synthi extends Klangmittel{
    public void generiereTon(){
        System.out.println("Klanggenerator");
    }

    @Override
    public void erklingen() {
        generiereTon();
        gibTonHoehe();
    }
}
