package tikTat;

import javafx.scene.control.Button;

public class GameForms extends Button {

    private boolean player;

    public GameForms(){
        this.setPrefSize(120,120);
    }

    public String text(){
        return this.getText();
    }

}
