public class Main {

    public static void main(String[] args)
    {
          var countires = new String[]{"Nigeria", "India" , "USA"};
          var names = new String[]{"Tom", "Tim", "Tina"};
          var scores = new Integer[]{22,46,66,92};
          var letters = new Character[]{'a','b', 'c','d'};


          var store1 = new Store<>(countires);
          var store2 = new Store<>(scores);
          var store3 = new Store<>(names);
          var store4 = new Store<>(letters);

          store4.greaterThan(store1);
          store4.sameSize(store2);
          store4.paritätNumber(store2);

    }
}
