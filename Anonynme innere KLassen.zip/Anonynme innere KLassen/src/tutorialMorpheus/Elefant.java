package tutorialMorpheus;

public class Elefant extends Tier{
    @Override
    public void macheDichBemerkbar() {
        System.out.println("Tarüüüüüüü");
    }
}
