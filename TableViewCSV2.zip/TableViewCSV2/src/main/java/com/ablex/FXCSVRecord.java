package com.ablex;

import javafx.beans.property.Property;

import java.util.HashMap;
import java.util.Map;

public class FXCSVRecord {

    private Map<Integer, Property> mapProperties = new HashMap<>();

    public Map<Integer, Property> getMapProperties() {
        return mapProperties;
    }
}
