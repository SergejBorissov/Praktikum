package tikTat.dennis;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class GameController {

    private Player player1;
    private Player player2;

    private Player currentPlayer;

    private int gameFieldSize;

    private Player[][] playedFields;

    private ObjectProperty<Player> playerWonProperty = new SimpleObjectProperty<>();

    public void registerPlayer1(Player player) {
        this.player1 = player;
    }

    public void registerPlayer2(Player player) {
        this.player2 = player;
    }

    public Player getNextPlayer() {
        if (currentPlayer == null) {
            currentPlayer = getRandomPlayer();
        } else if (currentPlayer == player1) {
            currentPlayer = player2;
        } else {
            currentPlayer = player1;
        }

        return currentPlayer;
    }

    public void playerPlayed(Player player, int x, int y) {
        playedFields[y][x] = player;

        playerWonProperty.set(getPlayerHasWonHorizontal());
    }

    public void setGameFieldSize(int gameFieldSize) {
        this.gameFieldSize = gameFieldSize;

        playedFields = new Player[gameFieldSize][gameFieldSize];
    }

    public ObjectProperty<Player> playerWon() {
        return playerWonProperty;
    }

    private Player getRandomPlayer() {
        return new Random().nextInt(2) == 0 ? player1 : player2;
    }

    private Player getPlayerHasWonHorizontal() {
        for (int y = 0; y < gameFieldSize; y++) {
            Set<Player> playerOnLength = new HashSet<>();
            for (int x = 0; x < gameFieldSize; x++) {
                Player player = playedFields[y][x];
                playerOnLength.add(player);

            }
            if (playerOnLength.size() == 1 && playerOnLength.iterator().next() != null) {
                return playerOnLength.iterator().next();
            } else {
                playerOnLength.clear();
            }
        }

        return null;
    }
}
