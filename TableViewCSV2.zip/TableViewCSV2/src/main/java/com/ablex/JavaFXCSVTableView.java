package com.ablex;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;


public class JavaFXCSVTableView extends Application {


    private final TableView<FXCSVRecord> tableView = new TableView<>();


    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("TableViewCSVParser2");


        VBox vBox = new VBox();
        vBox.setSpacing(10);
        vBox.getChildren().add(tableView);
        VBox.setVgrow(tableView, Priority.ALWAYS);
        vBox.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);


        primaryStage.setScene(new Scene(vBox, 700, 250));
        primaryStage.show();

        readCSV();
    }

    private void readCSV() {

        final File file = new File("/home/sborissov/Schreibtisch/beispiel.csv");

        try (final CSVParser p = CSVParser.parse(file, StandardCharsets.UTF_8, CSVFormat.newFormat(';'))) {

            final List<CSVRecord> records = p.getRecords();

            CSVRecord csvRecordHeader = records.get(0);
            Map<Integer, String> headerNames = new LinkedHashMap<>();
            for (int column = 0; column < csvRecordHeader.size(); column++) {
                headerNames.put(column, csvRecordHeader.get(column));
            }
            buildTableColumns(headerNames);

            for (int row = 1; row < records.size(); row++) {
                CSVRecord csvRecord = records.get(row);
                FXCSVRecord fxcsvRecord = new FXCSVRecord();

                for (int column = 0; column < csvRecord.size(); column++) {
                    //hinein in die Tabelle....ObservableList vllt?!
                    System.out.println(csvRecord.get(column));
                    fxcsvRecord.getMapProperties().put(column, new SimpleStringProperty(csvRecord.get(column)));

                }
                tableView.getItems().add(fxcsvRecord);
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(JavaFXCSVTableView.class.getName())
                    .log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JavaFXCSVTableView.class.getName())
                    .log(Level.SEVERE, null, ex);
        }


    }

    private void buildTableColumns(Map<Integer, String> headerNames) {
        tableView.getColumns().clear();
        tableView.getColumns().addAll(headerNames.entrySet().stream()
                .map(t -> buildTableColumn(t.getValue(), t.getKey()))
                .collect(Collectors.toList()));
    }

    private TableColumn<FXCSVRecord, ?> buildTableColumn(String name, int index) {
        TableColumn<FXCSVRecord, Object> tableColumn = new TableColumn<>(name);

        tableColumn.setCellValueFactory(param -> param.getValue().getMapProperties().get(index));

        return tableColumn;
    }

    public static void main(String[] args) {
        launch(args);
    }

}
