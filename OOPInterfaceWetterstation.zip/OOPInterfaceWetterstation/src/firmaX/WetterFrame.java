package firmaX;

import firmaY.WetterstationDummy;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import firmaY.WetterstationDummy;

public class WetterFrame extends JFrame implements ActionListener{

    private JButton temperaturButton, luftdruckButton;
    private JLabel temperaturLabel, luftdruckLabel;
    private Wetterstation wetterstation;

    public WetterFrame(){

        super("Wetterstation 1.0");

        wetterstation = new WetterstationDummy();

        setLayout(new GridLayout(2,2));
        temperaturButton = new JButton("Hole Temperatur");
        temperaturButton.addActionListener(this);
        luftdruckButton = new JButton("Hole Luftdruck");
        luftdruckButton.addActionListener(this);

        temperaturLabel = new JLabel();
        luftdruckLabel = new JLabel();

        add(temperaturButton);
        add(temperaturLabel);
        add(luftdruckButton);
        add(luftdruckLabel);

        setSize(400,100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==temperaturButton){
            temperaturLabel.setText("Temperatur: " + wetterstation.getGradCelsius());

        }else if(e.getSource() == luftdruckButton){
            luftdruckLabel.setText("Luftdruck: " + wetterstation.getLuftdruck() + " hPa");
        }

    }

}