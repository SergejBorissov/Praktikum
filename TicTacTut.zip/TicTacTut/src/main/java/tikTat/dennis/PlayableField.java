package tikTat.dennis;

import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;


/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class PlayableField extends StackPane {

    private static final String CSS_CLASS = "playable-field";

    private int x;
    private int y;

    private GameController gameController;

    public PlayableField(GameController gameController, int x, int y) {
        this.gameController = gameController;
        this.x = x;
        this.y = y;

        initPane();
        initMouseClickEventHandler();
    }

    private void initPane(){
        this.setMinSize(50, 50);
        this.getStyleClass().add(CSS_CLASS);
    }

    private void initMouseClickEventHandler(){
        this.addEventHandler(MouseEvent.MOUSE_CLICKED, this::handleMouseClickedAction);
    }

    private void handleMouseClickedAction(MouseEvent mouseEvent){
        Player player = gameController.getNextPlayer();
        GameIcon gameIcon = player.getGameIconFactory().buildGameIcon();
        gameController.playerPlayed(player, x, y);
        this.getChildren().add(gameIcon);
    }

}
