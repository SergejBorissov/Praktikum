public class NumberRecord

{
    public static void main(String[] args)
    {
        int[] numberRecords = new int[12];

        NumberCreater numberObject = new NumberCreater();

        for(int i = 0; i < numberRecords.length; i++)
        {
            numberObject.generiereZahl();
        }
    }
}