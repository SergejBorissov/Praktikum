package animationFX;

import javafx.application.Application;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Point3D;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

import javafx.scene.shape.Polygon;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;

public class HauptMenu implements Initializable
{
    @FXML
    private Button button;

    @FXML
    Polygon polygon;

    @FXML
    private Slider slider;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        VBox vBox = new VBox();
        vBox.setAlignment(Pos.CENTER);
        vBox.setStyle("-fx-background-color: #667794;");

//        polygon.translateZProperty().bind(slider.valueProperty());
//        polygon.translateYProperty().bind(slider.valueProperty());
//        polygon.setRotationAxis(new Point3D());
        polygon.rotateProperty().bind(slider.valueProperty());
//                polygon.setRotationAxis(Rotate.Y_AXIS);
//        slider.valueProperty().addListener(new ChangeListener<Number>() {
//            @Override
//            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
//                polygon.setRotationAxis(new Point3D(newValue.doubleValue(), newValue.doubleValue(), newValue.doubleValue()));
//            }
//        });

        Label infoLabel = new Label("Spielfeldgröße");
        infoLabel.setTextFill(Color.BLACK);


//        slider.valueProperty().addListener((obs, oldval, newVal) ->
//                slider.setValue(newVal.intValue()));

        slider.valueProperty().addListener(new ChangeListener<Number>()
        {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                                Number oldValue, Number newValue)
            {

            }
        });



        vBox.setSpacing(10);
        vBox.setPadding(new Insets(15,20, 10,10));

        Button buttonStart= new Button("Start");
        buttonStart.setPrefSize(100,100);
        vBox.getChildren().add(buttonStart);

        Button buttonExit = new Button("Beenden");
        buttonExit.setPrefSize(100, 100);
        vBox.getChildren().add(buttonExit);
        buttonExit.addEventHandler(MouseEvent.MOUSE_CLICKED, keyEvent ->{
            try{
                System.out.println("erster");
                keyEvent.consume();
            } catch(Exception e){
                e.printStackTrace();
            }

        });
        vBox.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                System.out.println("sdf");
            }
        });

        TextField textName1 = new TextField("Feldgröße: ");
        textName1.setPrefWidth(110);
        textName1.setMaxWidth(300);

        TextField textName2 = new TextField("Name Spieler 2");
        textName2.setPrefWidth(110);
        textName2.setMaxWidth(300);


        buttonStart.setOnAction(e -> {
            QuaderMatrix quaderMatrix = new QuaderMatrix();
//            try {
//                quaderMatrix.start(primaryStage);
//
//            } catch (MalformedURLException malformedURLException) {
//                malformedURLException.printStackTrace();
//            }
        });
    }

    @FXML
    private void handleButtonAction(ActionEvent event){
        System.out.println("fuuuuuu");
    }
}
