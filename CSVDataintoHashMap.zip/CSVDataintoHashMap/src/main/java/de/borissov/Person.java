package de.borissov;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;


public static class Person {

    private final SimpleStringProperty vorname;
    private final SimpleStringProperty nachname;
    private final SimpleIntegerProperty alter;



    Person(String vName, String nName, int alter) {
        this.vorname = new SimpleStringProperty(vName);
        this.nachname = new SimpleStringProperty(nName);
        this.alter = new SimpleIntegerProperty(alter);
    }



    }


    public String getVorname() {
        return vorname.get();
    }

    public void setVorname(int fName) {
        vorname.set(fName);
    }

    public String getNachname() {
        return nachname.get();
    }

    public void setLastName(String fName) {
        nachname.set(fName);
    }

    public int getAlter(){
        return alter.get();
    }

    public void setAlter(int fAlter){
        alter.set(fAlter);
    }
}