package firmaX;

public class XStart {

    public static void main(String[] args) {

        new WetterFrame();
    }
}
