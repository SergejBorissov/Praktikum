package data;

import java.util.regex.Matcher;

public class Pattern {

    private static void versuch(){
        StringBuilder tagsKette = new StringBuilder("<Name>Anselm</Name><Nachname>Kiefer</Nachname>");
        String pattern = "^>.*<";

        java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
        Matcher m = p.matcher(tagsKette);

        while (m.find()) {
            System.out.print(m.start() + " ");
        }
    }

    public static void main(String[] args) {
       versuch();
    }

}
