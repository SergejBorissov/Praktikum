package com.ablex.parser;

import com.ablex.model.DataModel;

import java.util.List;

public interface DataWriter
{

    public String writeData(List<DataModel> dataModelList);

}
