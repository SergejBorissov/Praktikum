public class Haus implements Comparable<Haus>
{

    private int quadratmeter;
    private String adresse;

    public Haus(int quadratmeter, String adresse)
    {
         super();
         this.quadratmeter = quadratmeter;
         this.adresse = adresse;
    }

    public int getQuadratmeter()
    {
        return quadratmeter;
    }

    public String getAdresse()
    {
        return adresse;
    }

    public String toString()
    {
        return this.quadratmeter + "m2 " + this.adresse + " ";
    }

    @Override
    public int compareTo(Haus o)
    {
        return this.quadratmeter - o.getQuadratmeter();
    }

}
