package com.ablex.parser;

public interface DataReader
{
    public void readData(String fileName);
}
