package tutorialMorpheus;

public class Hund extends Tier{
    @Override
    public void macheDichBemerkbar() {
        System.out.println("Wuff");
    }
}
