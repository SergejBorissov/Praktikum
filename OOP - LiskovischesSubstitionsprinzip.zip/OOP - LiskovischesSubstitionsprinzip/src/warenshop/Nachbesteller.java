package warenshop;

public class Nachbesteller {

    public static void main(String[] args) {

        Pizza pizza = new Pizza();
        BlueRayPlayer blueRayPlayer = new BlueRayPlayer();
        Heizdecke heizdecke = new Heizdecke();
        Brot brot = new Brot();
        Chips chips = new Chips();

        nachbestellen(pizza);
        nachbestellen(blueRayPlayer);
        nachbestellen(heizdecke);
        nachbestellen(brot);
        nachbestellen(chips);

    }

    //Polymorphe Methode := liskovisches substitionsprinzip
    //bedeutet, das Objekt schlüpft in die Rolle der Vaterklasse
    public static void nachbestellen(Ware ware){
        //Upcast
        System.out.println(" Bestellug der Ware:  " + ware.bezeichnung);

        //Downcast
     if(ware instanceof Brot)
        System.out.println(" Geschnitten: " + ((Brot)ware).geschnitten);

     if( ware instanceof Pizza)
         System.out.println(" Sorte : " + ((Pizza)ware).sorte);


    }
}
