package com.ablex.model;

import java.util.List;

public class DataModel
{

    private List<String> values;

    public DataModel(List<String> values) {
        this.values = values;
    }

    public List<String> getValues() {
        return values;
    }

    public void setValues(List<String> values) {
        this.values = values;
    }


}


