package com.ablex.converter;

public class Converter
{
    private String dataBeforeParsing;
    private String dataAfterParsing;
    private boolean sameData;


    public void convertCSVToJSON()
    {

    }

    public void convertJSONToCSV()
    {

    }
}
