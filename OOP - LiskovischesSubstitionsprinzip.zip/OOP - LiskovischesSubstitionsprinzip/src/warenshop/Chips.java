package warenshop;

public class Chips extends Lebensmittel{

    protected String sorte = "gesalzen";
}
