package info.borissov;

import javafx.beans.property.SimpleStringProperty;

public class Person {

    private SimpleStringProperty nummer, name, nachname, funktion, anfang, ende;

    public String getNummer() {
        return nummer.get();
    }

    public String getName() {
        return name.get();
    }

    public String getNachname() {
        return nachname.get();
    }

    public String getFunktion() {
        return funktion.get();
    }

    public String getAnfang() {
        return anfang.get();
    }

    public String getEnde() {
        return ende.get();
    }

    Person(String nummer, String name, String nachname, String funktion,
           String anfang, String ende) {
        this.nummer = new SimpleStringProperty(nummer);
        this.name = new SimpleStringProperty(name);
        this.nachname = new SimpleStringProperty(nachname);
        this.funktion = new SimpleStringProperty(funktion);
        this.anfang = new SimpleStringProperty(anfang);
        this.ende = new SimpleStringProperty(ende);
    }

}
