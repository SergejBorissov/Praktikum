package tikTat.dennis;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */



public class TicTacToeApplication extends Application {



    @Override
    public void start(Stage primaryStage) throws Exception {


        GameController gameController = new GameController();
        gameController.playerWon().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                System.out.println("player " + newValue.toString() + " has won");
            }
        });

        gameController.registerPlayer1(new Player("Player 1", () -> new GameIcon("X")));
        gameController.registerPlayer2(new Player("Player 2", () -> new GameIcon("O")));

        GameField gameField = new GameField(3, gameController);

        MenuBar menuBar = new MenuBar();

        Menu neues_spiel = new Menu("Neues Spiel");
        Menu editMenu = new Menu("edit");
        Menu helpMenu = new Menu("help");
        menuBar.autosize();

        //mit subMenu auswahl der spielfeldgröße
        MenuItem newItem = new MenuItem("Spiel starten");
        MenuItem openFileItem = new MenuItem("Spielstand");
        MenuItem exitItem = new MenuItem("beenden");

        newItem.setOnAction((ActionEvent e) -> {
            System.out.println("Neues Spiel wird gestartet");
        });

        openFileItem.setOnAction((ActionEvent e) -> {

        });


        exitItem.setAccelerator(KeyCombination.keyCombination("Ctrl+X"));
        exitItem.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });


        MenuItem copyItem = new MenuItem("copy");
        MenuItem pasteItem = new MenuItem("paste");

        neues_spiel.getItems().addAll(newItem, openFileItem, exitItem);
        editMenu.getItems().addAll(copyItem,pasteItem);
        menuBar.getMenus().addAll(neues_spiel,editMenu,helpMenu);

        gameField.getChildren().add(menuBar);
        primaryStage.setScene(new Scene(gameField));
        primaryStage.getScene().getStylesheets().add(getClass().getResource("design.css").toExternalForm());

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
