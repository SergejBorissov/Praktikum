package tikTat.dennis;

import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.StackPane;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class GameIcon extends StackPane {




    private static final String CSS_CLASS = "game-sign";

    private Label labelIcon = new Label();

    public GameIcon(String icon) {
        this.labelIcon.setText(icon);

        initPane();
    }

    private void initPane() {
        this.getStyleClass().add(CSS_CLASS);

        this.getChildren().add(labelIcon);
    }
}
