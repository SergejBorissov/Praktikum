package data;

import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;

public class TableView extends StackPane {


    private final javafx.scene.control.TableView<Main> tableView = new javafx.scene.control.TableView<>();

    public TableView() {
        initTableColumns();
        initPane();
    }

    public ObservableList<Main> getItems() {
        return tableView.getItems();
    }

    private void initTableColumns() {
        TableColumn columnNummer = new TableColumn("Nummer");
        columnNummer.setCellValueFactory(
                new PropertyValueFactory<>("Nummer"));

        TableColumn columnName = new TableColumn("Name");
        columnName.setCellValueFactory(
                new PropertyValueFactory<>("Name"));

        TableColumn columnNachname = new TableColumn("Nachname");
        columnNachname.setCellValueFactory(
                new PropertyValueFactory<>("Nachname"));

        TableColumn columFunktion = new TableColumn("Funktion");
        columFunktion.setCellValueFactory(
                new PropertyValueFactory<>("Funktion"));

        TableColumn columnAnfang = new TableColumn("Anfang");
        columnAnfang.setCellValueFactory(
                new PropertyValueFactory<>("Anfang"));

        TableColumn columnEnde = new TableColumn("Ende");
        columnEnde.setCellValueFactory(
                new PropertyValueFactory<>("Ende"));

        tableView.getColumns().addAll(
                columnNummer, columnName, columnNachname, columFunktion, columnAnfang, columnEnde);
    }

    private void initPane() {
        this.getChildren().add(tableView);
    }
}



