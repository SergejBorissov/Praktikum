public class Bass extends Klangmittel{

    public void zupfeBass(){
        System.out.println("Tiefe Bässe");
    }

    @Override
    public void erklingen(){
        zupfeBass();
    }
}
