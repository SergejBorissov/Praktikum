package warenshop;

public  class Ware {

    protected String bezeichnung;
    protected int artikelnummer;
    protected double preis;
}
