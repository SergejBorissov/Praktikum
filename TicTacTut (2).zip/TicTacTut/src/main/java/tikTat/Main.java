package tikTat;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.stage.Stage;


public class Main extends Application {

    Button spielStart;
    Button exit;
    VBox vBox;
    HBox hBox;
    Stage game;

    @Override
    public void init(){
        spielStart = new Button("Spiel Starten");
        exit = new Button("Spiel Beenden");
        vBox = new VBox();
        hBox = new HBox();

    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        game = new Stage();


        vBox.setSpacing(10);
        hBox.setSpacing(10);
        vBox.setPadding(new Insets(15,20,10,10));
        vBox.getChildren().addAll(spielStart,exit);
        hBox.getChildren().add(vBox);

        spielStart.setOnAction((ActionEvent event) -> {
            System.out.println("Spiel wird gestartet");
            GameFrame gameFrame = new GameFrame();
            try{
                gameFrame.start(primaryStage);
            } catch(Exception e){
                System.out.println("Fehler");
            }
        });

        exit.setOnAction((ActionEvent e) -> {
            System.exit(0);
                });

        BorderPane root = new BorderPane();
        root.getChildren().add(vBox);


        Scene scene = new Scene(root, 500,600);
        primaryStage.setTitle("TikTakVersion4");
        scene.getStylesheets().add(getClass().getResource("design.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
