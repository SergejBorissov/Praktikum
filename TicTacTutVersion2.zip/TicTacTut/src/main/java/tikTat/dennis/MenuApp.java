package tikTat.dennis;

import javafx.scene.control.MenuBar;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MenuApp {



    public void start(Stage primaryStage){

        BorderPane root = new BorderPane();
        MenuBar menuBar = new MenuBar();


    }
}
