package de.borissov;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;



import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class App extends Application{

    private final ObservableList data =
            FXCollections.observableArrayList(
                    new Person(),
                    new Person(),
                    new Person()
            );



    @Override
    public void start(Stage primaryStage) {
        try {
            // wir legen unser GridPane an
            GridPane grid = new GridPane();
            // weisen das Padding (interner Abstand) zu
            grid.setPadding(new Insets(10, 10, 10, 10));
            // und fügen einen kleinen Außenabstand hinzu
            grid.setVgap(10);
            grid.setHgap(10);

            TableView table = new TableView();
            table.setEditable(true);

            TableColumn vorNameCol = new TableColumn("Vorname");
            TableColumn nachNameCol = new TableColumn("Nachname");
            TableColumn alterCol = new TableColumn("Alter");

            table.getColumns().addAll(vorNameCol, nachNameCol, alterCol);


            vorNameCol.setMinWidth(100);
            vorNameCol.setCellValueFactory(
                    new PropertyValueFactory<>("vorname"));


            nachNameCol.setMinWidth(100);
            nachNameCol.setCellValueFactory(
                    new PropertyValueFactory<>("nachname"));

            alterCol.setMinWidth(100);
            alterCol.setCellValueFactory(
                    new PropertyValueFactory<>("alter"));

            table.setItems(data);

            GridPane.setConstraints(table, 0,0);

            grid.getChildren().addAll(table);

            Scene scene = new Scene(grid,400,300);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }




    public static void main(String[] args) {

        launch(args);

        String csvFilePath = "/home/sborissov/Schreibtisch/person.csv";
        try {
            BufferedReader lineRead = new BufferedReader(new FileReader(csvFilePath));
            CSVParser records = CSVParser.parse(lineRead, CSVFormat.EXCEL.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
            Map<Integer, Person> studentMap = new HashMap<Integer, Person>();
            for(CSVRecord record : records){
                Person person = new Person(); //vorname, nachname?!
                person.setVorname(Integer.parseInt(record.get(0)));
                person.setLastName(record.get(1));

                //Speicherung der Daten in der Map
                studentMap.put(Integer.parseInt(record.get(0)), person);
            }

            System.out.println(studentMap);

            Collection collection = studentMap.values();
            Iterator iterator = collection.iterator();
            while(iterator.hasNext() != false){
                Person person = (Person)iterator.next();
                System.out.println(person.getVorname() + "  "+ person.getVorname());
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }




}
