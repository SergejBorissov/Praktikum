public abstract class Tier
{
    public double gewicht = 0;
    public int alter = 1;

    public void macheDichBemerkbar()
    {
        System.out.println("Tier");
    }

    public void doSomething(int i)
    {
        System.out.println(i);
        if(i==0)
        {
           return;
        }
        this.doSomething(i - 1);

    }

    public double getGewicht()
    {
        return this.gewicht;
    }
    public int getAlter()
    {
        this.lassZeitVergehen();
        return  this.alter;
    }
    private void lassZeitVergehen()
    {
        this.alter++;
    }
}
