public class Schlagzeug extends Klangmittel{
    public void beat(){
        System.out.println("Drums");
    }

    @Override
    public void erklingen(){
        beat();
    }
}
