import java.util.TreeMap;

public class Makler
{
    private TreeMap<Haus, String> kaufliste;

    public Makler()
    {
        super();
        this.kaufliste = new TreeMap<Haus, String>();
    }

    public void neuesHaus(int m2, String adresse, String notiz)
    {
        kaufliste.put(new Haus(m2, adresse), notiz);
    }

    public Haus holeKleintesHaus()
    {
        return kaufliste.firstKey();
    }

    public String holeNotiz(Haus haus)
    {
        return kaufliste.get(haus);
    }

    public static void main(String[] args)
    {
        Makler makler = new Makler();

        makler.neuesHaus(100, "Gasse 12", "optimal für");
        makler.neuesHaus(112,"goethe straße", "zu alt");

        System.out.println("Kleines Haus: " + makler.holeKleintesHaus().toString());
        makler.neuesHaus(93, "Freie Straße 12", "interessant");

        System.out.println("Diesmal das kleinste Haus: " + makler.holeKleintesHaus().toString());

        System.out.println("Notiz: " + makler.holeNotiz(makler.holeKleintesHaus() ));

    }
}
