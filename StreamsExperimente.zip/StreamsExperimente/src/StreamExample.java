import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Stream;

public class StreamExample {

    public static void main(String[] args) {

        Object[] words = {"  ", " Alles", 123, "Nichts", null};
        Arrays.stream(words);

        Stream<String> reihe = new ArrayList<String>().stream().map(StreamExample::change);
        new ArrayList<String>().stream().map(s -> words );


    }

    private static String change(String s) {
        return s + "bla";
    }
}
