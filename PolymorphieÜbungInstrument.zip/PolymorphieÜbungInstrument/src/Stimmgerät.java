public interface Stimmgerät {

    public static void stimmeSaiten(){};
}
