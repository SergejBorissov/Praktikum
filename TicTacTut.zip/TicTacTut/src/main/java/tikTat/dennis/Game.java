package tikTat.dennis;

import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;

import java.util.Map;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class Game {

    public GameField startGame(int gameFieldSize, String player1, String player2, Runnable runnableBackToMainMenu){
        GameController gameController = new GameController();
        gameController.playerWon().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                System.out.println("player " + newValue.toString() + " has won");
            }
        });

        gameController.registerPlayer1(new Player(player1, () -> new GameIcon("X")));
        gameController.registerPlayer2(new Player(player2, () -> new GameIcon("O")));

        GameField gameField = new GameField(gameFieldSize, gameController);
        gameField.setRunnableBackToMainMenu(runnableBackToMainMenu);
        //gameField.setRunnableGameExit(runnableGameExit);

        return gameField;
    }
}
