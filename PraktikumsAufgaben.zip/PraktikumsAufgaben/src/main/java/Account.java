/**
 * javaDoc
 *
 * @author gloewen
 */
public class Account {

    private int nr;

    private double balance;

    public Account(int nr) {
        this.nr = nr;
    }

    void transfer(double money) {
        System.out.println("Änderung der Kontostands:\tKontonr.: " + nr + "\tAlter Kontostand: " + balance + " €");
        balance += money;
        balance = balance < 0 ? balance - 10 : balance;
        System.out.println("\t\tKontonr.: " + nr + "\tNeuer Kontostand: " + balance + " €");
    }

    public int getNr() {
        return nr;
    }

    public double getBalance() {
        return balance;
    }

    @Override

    public String toString() {
        return "Kontonummer: " + nr + "\tKontostand: " + balance + " €";
    }
}
