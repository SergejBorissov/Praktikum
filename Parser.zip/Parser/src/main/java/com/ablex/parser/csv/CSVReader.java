package com.ablex.parser.csv;

import com.ablex.parser.DataReader;

public class CSVReader implements DataReader
{
    private String fileName;

    @Override
    public void readData(String fileName) {

    }
}
