package com.ablex.main;

import com.ablex.controller.DataModelController;
import com.ablex.view.MainFrame;
import com.ablex.view.MainFrameFactory;
import javafx.application.Application;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {


        MainFrame frame = MainFrameFactory.getInstance().createFrame();
        Scene scene = new Scene(frame.getRootPane(), 650, 850);

        scene.setCamera(new PerspectiveCamera());
        primaryStage.setTitle("setQuaderMatrix");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
}
