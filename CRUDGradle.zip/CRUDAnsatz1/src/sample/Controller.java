package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.awt.event.ActionEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    private Label label;
    @FXML
    private TextField tfid;
    @FXML
    private TextField tftitle;
    @FXML
    private TextField tfauthor;
    @FXML
    private TextField tfyear;
    @FXML
    private TextField tfpages;
    @FXML
    private TableView<Books> tableViewBooks;
    @FXML
    private LineChart<Books,Integer> lineChart;
    @FXML
    private TableColumn<Books, Integer> columnId;
    @FXML
    private TableColumn<Books,String> columnTitle;
    @FXML
    private TableColumn<Books,String> columnAuthor;
    @FXML
    private TableColumn<Books,Integer> columnYear;
    @FXML
    private TableColumn<Books,Integer> columnPages;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;

    @FXML
    public void handleButtonAction(javafx.event.ActionEvent actionEvent) {
        System.out.println("Es wurde gecklickt");
        label.setText("Du hast getippt");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        showBooks();

    }

    public Connection getConnection(){
        Connection conn;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Berlin",
                                               "root", "");
            return conn;
        } catch(Exception ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }

    public ObservableList<Books> getBooksList(){
        ObservableList<Books> bookList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * FROM books";
        Statement st;
        ResultSet rs;

        try{
            st = conn.createStatement();
            rs = st.executeQuery(query);
            Books books;
            while(rs.next()){
                books = new Books(rs.getInt("id"),rs.getString("title"),
                                  rs.getString("author"), rs.getInt("year"),
                                  rs.getInt("pages"));
                bookList.add(books);
            }
        } catch(Exception ex){
              ex.printStackTrace();
        }
        return bookList;
    }

    public void showBooks(){
         ObservableList<Books> list = getBooksList();
         columnId.setCellValueFactory(new PropertyValueFactory<Books, Integer>("id"));
         columnTitle.setCellValueFactory(new PropertyValueFactory<Books, String>("title"));
         columnAuthor.setCellValueFactory(new PropertyValueFactory<Books, String>("author"));
         columnYear.setCellValueFactory(new PropertyValueFactory<Books, Integer>("year"));
         columnPages.setCellValueFactory(new PropertyValueFactory<Books, Integer>("pages"));

         tableViewBooks.setItems(list);


    }


}
