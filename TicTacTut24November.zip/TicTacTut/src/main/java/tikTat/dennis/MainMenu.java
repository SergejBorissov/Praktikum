package tikTat.dennis;

import javafx.application.Application;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.util.function.Function;

public class MainMenu extends Application {

    public void start(Stage primaryStage) throws Exception {

        VBox vBox = new VBox();
        vBox.setAlignment(Pos.CENTER);
        vBox.setStyle("-fx-background-color: #667794;");

        Label infoLabel = new Label("Spielfeldgröße");
        infoLabel.setTextFill(Color.BLACK);

        Slider slider = new Slider(0, 200, 1);
        slider.setShowTickLabels(true);
        slider.setMaxWidth(500);
        slider.setShowTickMarks(true);

        slider.valueProperty().addListener((obs, oldval, newVal) ->
                slider.setValue(newVal.intValue()));

        slider.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                infoLabel.setText("Spielfledgröße:  " + newValue);
            }
        });

        slider.setOnScroll(event -> slider.setValue(slider.getValue() + event.getDeltaY()));
        slider.setValue(3);

        StackPane stackPane = new StackPane();
        stackPane.getChildren().add(slider);

        vBox.setSpacing(10);
        vBox.setPadding(new Insets(15, 20, 10, 10));

        Button buttonStart = new Button("Start");
        buttonStart.setPrefSize(100, 100);
        vBox.getChildren().add(buttonStart);



        Button buttonExit = new Button("Beenden");
        buttonExit.setPrefSize(100, 100);
        vBox.getChildren().add(buttonExit);
        buttonExit.setOnAction(event -> System.exit(0));
        TextField textName1 = new TextField("Name Spieler 1");
        textName1.setPrefWidth(110);
        textName1.setMaxWidth(300);

        TextField textName2 = new TextField("Name Spieler 2");
        textName2.setPrefWidth(110);
        textName2.setMaxWidth(300);

        Label nowInputLabel = new Label();
        nowInputLabel.setTextFill(Color.PALEGREEN);
        nowInputLabel.textProperty().bind(textName1.textProperty());

        vBox.getChildren().addAll(textName1, textName2, slider, infoLabel, nowInputLabel);


        Scene scene = new Scene(vBox, 650, 850);

        primaryStage.setTitle("TikTakismus");
        primaryStage.setScene(scene);
        primaryStage.getScene().
                getStylesheets().
                add(getClass().getResource("design.css").
                        toExternalForm());
        primaryStage.show();


        buttonStart.setOnAction(e -> {
            GameField gameField = new Game().startGame(slider.valueProperty().getValue().intValue(),
                            textName1.getText(),
                            textName2.getText(), () -> scene.setRoot(vBox));


            scene.setRoot(gameField);
            gameField.setAlignment(Pos.CENTER);
        });

    }

    private void doAction(ActionEvent event){

    }

    public static void main(String[] args) {
        launch(args);
    }


}
