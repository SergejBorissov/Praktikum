package crud;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class Controller implements Initializable {


    @FXML
    private TextField tfid;
    @FXML
    private TextField tftitle;
    @FXML
    private TextField tfauthor;
    @FXML
    private TextField tfyear;
    @FXML
    private TextField tfpages;
    @FXML
    private TableView<Books> tableViewBooks;
    @FXML
    private LineChart<String,Integer> lineChart;
    @FXML
    private TableColumn<Books, Integer> columnId;
    @FXML
    private TableColumn<Books,String> columnTitle;
    @FXML
    private TableColumn<Books,String> columnAuthor;
    @FXML
    private TableColumn<Books,Integer> columnYear;
    @FXML
    private TableColumn<Books,Integer> columnPages;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;

   
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        showBooks();

    }

    @FXML
    public void handleButtonAction(javafx.event.ActionEvent actionEvent) {
        XYChart.Series<String,Integer> series = new XYChart.Series<>();

        series.getData().add(new XYChart.Data<String, Integer>("Pages", tfpages.getPrefColumnCount()));
        series.getData().add(new XYChart.Data<String, Integer>("wert",tfyear.getPrefColumnCount()));
        series.getData().add(new XYChart.Data<String, Integer>("sw",tfid.getPrefColumnCount()));

        lineChart.getData().add(series);


        if(actionEvent.getSource()==btnInsert){
            insertRecord();
        } else if(actionEvent.getSource()==btnUpdate){
            updateRecord();
        } else if(actionEvent.getSource() == btnDelete){
            deleteButton();
        }

    }


    public Connection getConnection(){
        Connection conn;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test",
                                               "root", "");
            return conn;
        } catch(Exception ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }

    public ObservableList<Books> getValueForLineChart(){
        // abhören der spezifischen Zahlen Werte für die weitergabe ans LineCHart
        return null;
    }

    public ObservableList<Books> getBooksList(){
        ObservableList<Books> bookList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * FROM bib";
        Statement st;
        ResultSet rs;

        try{
            st = conn.createStatement();
            rs = st.executeQuery(query);
            Books books;
            while(rs.next()){
                books = new Books(rs.getInt("id"),rs.getString("title"),
                                  rs.getString("author"), rs.getInt("year"),
                                  rs.getInt("pages"));
                bookList.add(books);
            }
        } catch(Exception ex){
              ex.printStackTrace();
        }
        return bookList;
    }


    public void showBooks(){
         ObservableList<Books> list = getBooksList();
         columnId.setCellValueFactory(new PropertyValueFactory<Books, Integer>("id"));
         columnTitle.setCellValueFactory(new PropertyValueFactory<Books, String>("title"));
         columnAuthor.setCellValueFactory(new PropertyValueFactory<Books, String>("author"));
         columnYear.setCellValueFactory(new PropertyValueFactory<Books, Integer>("year"));
         columnPages.setCellValueFactory(new PropertyValueFactory<Books, Integer>("pages"));

         tableViewBooks.setItems(list);

    }

    public void showLineVaules(){
          // hier die Methode für das zeigen der Werte im LineChart
    }

    private void insertRecord(){
        String query = "INSERT INTO bib VALUES (" + tfid.getText() + ",'" + tftitle.getText() + "','" + tfauthor.getText() +
                "'," + tfyear.getText() + "," + tfpages.getText() + ")";
        executeQuery(query);
        showBooks();
    }

    private void updateRecord(){
        String query = "UPDATE bib SET title = '" + tftitle.getText() + "', author = '" + tfauthor.getText()
                + "', year = " + tfyear.getText() + ", pages = " + tfpages.getText() + " WHERE id = " + tfid.getText() + "";
        executeQuery(query);
        showBooks();

    }

    private  void deleteButton(){
        String query = "DELETE FROM bib WHERE id =" + tfid.getText() + "";
        executeQuery(query);
        showBooks();
    }

    private void executeQuery(String query) {
        Connection conn = getConnection();
        Statement st;
        try{
             st = conn.createStatement();
             st.executeUpdate(query);
        } catch(Exception ex){
             ex.printStackTrace();
        }

    }


}
