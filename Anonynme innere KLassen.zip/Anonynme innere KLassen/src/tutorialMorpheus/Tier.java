package tutorialMorpheus;

public abstract class Tier {
    public int beine;

    public abstract void macheDichBemerkbar();


}
