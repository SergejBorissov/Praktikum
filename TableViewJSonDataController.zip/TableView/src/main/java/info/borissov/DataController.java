package info.borissov;

import java.util.List;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public interface DataController {

    public List<Person> readData(String filename);
}
