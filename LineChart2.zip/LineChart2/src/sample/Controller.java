package sample;

import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;

import java.awt.event.ActionEvent;

public class Controller {

    @FXML LineChart<String, Number> lineChart;

    public void buttonPerform(javafx.event.ActionEvent actionEvent) {

        lineChart.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<String, Number>();
        series.getData().add(new XYChart.Data<String, Number>("Standart Converter", 200));
        series.getData().add(new XYChart.Data<String, Number>("Super Converter", 500));
        series.getData().add(new XYChart.Data<String, Number>("Jackson Converter", 900));
        series.getData().add(new XYChart.Data<String, Number>("Jsoniter ", 800));
        series.setName("Benchmark Parser Test");
        lineChart.getData().add(series);



    }




}
