package grafikMetriken;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;


public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {


            BorderPane root = new BorderPane();
            Scene scene = new Scene(root,900,900);
            root.setStyle("-fx-background-color: #5a1b1b;");


            Button buttonStart = new Button("Start");


            buttonStart.setStyle("-fx-border-color: #646464; -fx-border-width: 5px;");
            Scene sceneButton = new Scene(buttonStart, 120,120);


            for(int i = 0; i < 300; i++){
                Line line3 = new Line(55*i,i * 34,i * 10,500);
                line3.setStroke(Color.LIGHTBLUE);
                root.getChildren().add(line3);
            }
            for(int i = 0; i < 300; i++){
                Line line3 = new Line(25*i,i * 34,i * 10,500);
                line3.setStroke(Color.LIGHTBLUE);
                root.getChildren().add(line3);
            }
            for(int i = 0; i < 300; i++){
                Line line3 = new Line(30*i,i * 34,i * 10,500);
                line3.setStroke(Color.LIGHTBLUE);
                root.getChildren().add(line3);
            }
            for(int i = 0; i < 300; i++){
                Line line3 = new Line(35*i,i * 34,i * 10,500);
                line3.setStroke(Color.LIGHTBLUE);
                root.getChildren().add(line3);
            }
            for(int i = 0; i < 300; i++){
                Line line3 = new Line(40*i,i * 34,i * 10,500);
                line3.setStroke(Color.LIGHTBLUE);
                root.getChildren().add(line3);
            }
            for(int i = 0; i < 999; i++){
                Line line3 = new Line(500,i * 10,i * 5,65 * i);
                line3.setStroke(Color.YELLOWGREEN);
                root.getChildren().add(line3);
            }
            for(int i = 0; i < 999; i++){
                Line line3 = new Line(355,i * 8,i * 9,35 * i);
                line3.setStroke(Color.YELLOWGREEN);
                root.getChildren().add(line3);
            }


            root.getChildren().add(buttonStart);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}