package info.borissov;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class SettingsPane extends StackPane {

    private Button buttonReadCSV;

    private Button buttonReadJSON;

    private Button buttonReadXML;

    public SettingsPane() {
        initButtons();
        initPane();
    }

    public void setButtonReadCSVActionHandler(EventHandler<ActionEvent> eventEventHandler) {
        this.buttonReadCSV.setOnAction(eventEventHandler);
    }

    public void setButtonReadJSONActionHandler(EventHandler<ActionEvent> eventEventHandler) {
        this.buttonReadJSON.setOnAction(eventEventHandler);
    }

    public void setButtonReadXMLActionHandler(EventHandler<ActionEvent> eventEventHandler){
        this.buttonReadXML.setOnAction(eventEventHandler);
    }

    private void initButtons() {
        buttonReadCSV = new Button("Read CSV");

        buttonReadJSON = new Button("Read JSON");

        buttonReadXML = new Button("Read XML");


    }

    private void initPane() {
        HBox hBox = new HBox(5, buttonReadCSV, buttonReadJSON, buttonReadXML);

        this.getChildren().add(hBox);
    }

}
