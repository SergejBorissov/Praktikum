import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/**
 * javaDoc
 *
 * @author gloewen
 */
public class Bank {

    private String name;

    private List<Account> customerAccounts = new ArrayList<>();

    private int idCounter = 0;

    private Random rdm = new Random();

    public Bank(String name) {
        this.name = name;
    }


    public int createNewAccount() {

        Account newAccount = new Account(idCounter++);
        customerAccounts.add(newAccount);
        return newAccount.getNr();
    }

    public void printOverview() {
        customerAccounts.forEach(account -> System.out.println(account));
    }

    /**
     * @param fromAccountId Kontonummer des Überweisendenden
     * @param toAccountId   Kontonummer des Überweisungs-Empfängers
     * @param amount        Betrag
     */
    public void transfer(int fromAccountId, int toAccountId, double amount, boolean protectedTransfer) {
        new Thread(() -> {
            try {
                if (protectedTransfer) {
                    protectedTransfer(fromAccountId, toAccountId, amount);
                } else {
                    unprotectedTransfer(fromAccountId, toAccountId, amount);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    /**
     * @param fromAccountId Kontonummer des Überweisendenden
     * @param toAccountId   Kontonummer des Überweisungs-Empfängers
     * @param amount        Betrag
     * @return
     */
    private void unprotectedTransfer(int fromAccountId, int toAccountId, double amount) throws InterruptedException {
        _transfer(fromAccountId, toAccountId, amount);
    }

    /**
     * @param fromAccountId Kontonummer des Überweisendenden
     * @param toAccountId   Kontonummer des Überweisungs-Empfängers
     * @param amount        Betrag
     * @return
     */
    private synchronized void protectedTransfer(int fromAccountId, int toAccountId, double amount) throws InterruptedException {
        _transfer(fromAccountId, toAccountId, amount);
    }

    private void _transfer(int fromAccountId, int toAccountId, double amount) throws InterruptedException {
        for (int i = 0; i < customerAccounts.size(); i++) {
            Account currentAccount = customerAccounts.get(i);
            Thread.sleep(50);
            if (currentAccount.getNr() == fromAccountId) {
                Thread.sleep(rdm.nextInt(500));
                currentAccount.transfer(-amount);
            }
            if (currentAccount.getNr() == toAccountId) {
                Thread.sleep(rdm.nextInt(500));
                currentAccount.transfer(amount);
            }
        }
    }
}
