package animationFX;

import javafx.application.Application;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

import javafx.stage.Stage;

import java.net.MalformedURLException;

public class HauptMenu extends Application
{

    @Override
    public void start(Stage primaryStage) throws Exception
    {

        VBox vBox = new VBox();
        vBox.setAlignment(Pos.CENTER);
        vBox.setStyle("-fx-background-color: #667794;");

        Label infoLabel = new Label("Spielfeldgröße");
        infoLabel.setTextFill(Color.BLACK);

        Slider slider = new Slider(0, 200, 1);
        slider.setShowTickLabels(true);
        slider.setMaxWidth(500);
        slider.setShowTickMarks(true);

        slider.valueProperty().get();
        slider.valueProperty().addListener((obs, oldval, newVal) ->
                slider.setValue(newVal.intValue()));

        slider.valueProperty().addListener(new ChangeListener<Number>()
        {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                                Number oldValue, Number newValue)
            {
                infoLabel.setText("Spielfledgröße:  " + newValue);
            }
        });

        StackPane stackPane = new StackPane();
        stackPane.getChildren().add(slider);

        vBox.setSpacing(10);
        vBox.setPadding(new Insets(15,20, 10,10));

        Button buttonStart= new Button("Start");
        buttonStart.setPrefSize(100,100);
        vBox.getChildren().add(buttonStart);


        QuaderMatrix quaderMatrix = new QuaderMatrix();
        buttonStart.setOnAction(e ->
        {
            try
            {
                quaderMatrix.start(primaryStage);
            } catch (MalformedURLException malformedURLException)
            {
                malformedURLException.printStackTrace();
            }
        });

        Button buttonExit = new Button("Beenden");
        buttonExit.setPrefSize(100, 100);
        vBox.getChildren().add(buttonExit);

        buttonExit.setOnAction(event ->
        {
            System.exit(0);
        });

        TextField textName1 = new TextField("Feldgröße: ");
        textName1.setPrefWidth(110);
        textName1.setMaxWidth(300);

        TextField textName2 = new TextField("Name Spieler 2");
        textName2.setPrefWidth(110);
        textName2.setMaxWidth(300);

        vBox.getChildren().addAll(textName1,textName2,slider,infoLabel);

        Scene scene = new Scene(vBox, 650, 850);

        primaryStage.setTitle("QuaderMatrix");
        primaryStage.setScene(scene);
        primaryStage.show();


    }
    public static void main(String[] args)
    {
        launch(args);
    }
}
