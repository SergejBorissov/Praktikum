package com.ablex.controller;

import com.ablex.view.MainFrameFactory;

public class DataModelController {

    public DataModelController() {

    }
}
