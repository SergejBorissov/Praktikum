package warenshop;

public class Heizdecke  extends Elektroware{

    protected int breite;
    protected int laenge;

    public Heizdecke(){
        this.bezeichnung = "Heizdecke";
        this.artikelnummer = 2321;
        this.preis = 50;
        this.leistung = 220;
        this.spannung = 70;
        this.breite = 120;
        this.laenge = 200;

    }

}
