package com.ablex.view;

import javafx.fxml.FXMLLoader;

import java.io.IOException;

public class MainFrameFactory {

    private static final String FXML_NAME = "MainFrame.fxml";

    private static MainFrameFactory instance = null;

    private MainFrameFactory() {

    }

    public static MainFrameFactory getInstance(){
        if(instance==null){
            instance = new MainFrameFactory();
        }
        return instance;
    }

    public MainFrame createFrame() throws IOException {


        FXMLLoader fxmlLoader = new FXMLLoader(MainFrame.class.getResource(FXML_NAME));
        fxmlLoader.load();

        MainFrame mainFrame = new MainFrame(fxmlLoader.getController(), fxmlLoader.getRoot());

        return mainFrame;

    }
}
