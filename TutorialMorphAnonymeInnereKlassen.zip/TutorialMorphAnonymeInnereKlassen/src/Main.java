import java.util.ArrayList;

public class Main
{

    public static void main(String[] args)
    {

        ArrayList<Tier> tiere = new ArrayList<Tier>();
        tiere.add(new Hund());
        tiere.add(new Elefant());
        tiere.add(new Tier()
        {
            @Override
            public void macheDichBemerkbar()
            {
                System.out.println("ein neues geräusch vom neuen Tier");
            }
        });

        //System.out.println(((Hund)tiere.get(0)).gewicht);
        for (int i = 0; i < tiere.size(); i++)
        {
            //  tiere.get(i).macheDichBemerkbar();

        }

        Tier tierNeu = new Elefant();
        tierNeu.doSomething(3);

        Hund hund = new Hund();
        if(hund instanceof Hund)
        {
            System.out.println("Hund gehört zur Gattung Tier");
        }
        Tier getier = (Tier)hund; //expliziter Upcast
        getier.macheDichBemerkbar();

        Elefant elefant = new Elefant();
        Tier einTier = elefant;  //Impliziter Upcast
        einTier.macheDichBemerkbar();


    }
}
