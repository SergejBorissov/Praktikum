package warenshop;

import java.util.Date;

public class Lebensmittel extends Ware{

    protected Date haltbarkeitsdatum;

}
