package hauptMenu;

import javafx.scene.layout.StackPane;

public class StartPart extends StackPane {

    public void gebeRaus(){


        System.out.println("Start gedrückt");

    }
}
