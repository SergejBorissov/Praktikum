import java.util.Random;

public class NumberCreater
{
   public int numberHolder1;

    Random random = new Random();

    public void generiereZahl()
    {
        numberHolder1 = random.nextInt(121);
        System.out.println(numberHolder1);
    }

}