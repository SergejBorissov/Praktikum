package warenshop;

public class BlueRayPlayer extends Elektroware{

    protected boolean hdmi;
    protected boolean dreiD;

    public BlueRayPlayer(){

        this.artikelnummer = 4;
        this.bezeichnung = "Blue-Ray-Player 4";
        this.preis = 77;
        this.leistung = 200;
        this.spannung = 220;
        this.hdmi = true;
        this.dreiD = false;

    }

}
