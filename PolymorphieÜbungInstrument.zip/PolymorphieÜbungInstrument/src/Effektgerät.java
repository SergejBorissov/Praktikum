public interface Effektgerät {

    public void macheEffekt();

}
