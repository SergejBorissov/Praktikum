public class Store<T> {

    T[] list;

    public Store(T[] list)
    {
        this.list = list;
    }

    public void greaterThan(Store<?> otherStore)
    {
        if(list.length > otherStore.list.length)
        {
            System.out.println("True");
        } else {
            System.out.println("false");
        }
    }

    public void sameSize(Store<?> otherStore)
    {
        if(list.length == otherStore.list.length)
        {
            System.out.println("Same Size");
        } else{
            System.out.println("Different Size");
        }
    }

    public void paritätNumber(Store<?> otherStore)
    {
        if((list.length + otherStore.list.length) % 2 == 0)
        {
            System.out.println("Gerade Zahl");
        } else {
            System.out.println("ungerade Zahl");
        }
    }
}
