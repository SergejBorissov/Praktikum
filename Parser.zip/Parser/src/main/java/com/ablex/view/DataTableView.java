package com.ablex.view;

import com.ablex.model.DataModel;

import java.util.List;

public class DataTableView
{
    private List<DataModel> dataModelList;

    public DataTableView(List<DataModel> dataModelList)
    {
        this.dataModelList = dataModelList;
    }

    public void add(DataModel dataModel)
    {

    }
}
