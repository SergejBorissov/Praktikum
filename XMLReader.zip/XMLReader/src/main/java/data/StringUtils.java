package data;

public class StringUtils {

    public static String substringBefore(String string, String delimiter){
        int position = string.indexOf(delimiter);
        return position >= 0 ? string.substring(0, position) : string;
    }

    public static String substringAfter(String string, String delimiter){
        int position = string.indexOf(delimiter);
        return position >= 0 ? string.substring(position + delimiter.length()) : "";
    }


    public static void main(String[] args) {
        System.out.println();
    }
}
