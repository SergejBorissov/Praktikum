package tikTat.dennis;

import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public class GameField extends GridPane {

    private GameController gameController;
    private int gameFieldSize;


    public GameField(int gameFieldSize, GameController gameController) {
        this.gameFieldSize = gameFieldSize;

        this.gameController = gameController;
        this.gameController.setGameFieldSize(gameFieldSize);

        initPane();
    }

    public void startGame() {
        Player nextPlayer = gameController.getNextPlayer();
    }

    private void initPane() {
        for (int x = 0; x < gameFieldSize; x++) {
            for (int y = 0; y < gameFieldSize; y++) {
                this.add(buildPlayableField(x, y), x, y);

            }
        }
    }

    private PlayableField buildPlayableField(int x, int y) {
        PlayableField playableField = new PlayableField(gameController, x, y);

        return playableField;
    }
}
