public class Tonstudio {

    public static void main(String[] args) {
        Synthi synthi = new Synthi();
        Gitarre gitarre = new Gitarre();
        Schlagzeug schlagzeug = new Schlagzeug();
        Bass bass = new Bass();

        mischeTon(synthi);
        mischeTon(gitarre);
        mischeTon(schlagzeug);
        mischeTon(bass);

    }

    public static void mischeTon(Klangmittel klangmittel){
        klangmittel.erklingen();
    }

    public static void gebeAus(int x){

    }
}
