package tikTat;

import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;

public class GameField extends StackPane {

   private GridPane gridPane = new GridPane();
   private GameForms[] gameFormsArray = new GameForms[9];
   private boolean player;

    GameField(){
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setGridLinesVisible(true);
        gridPane.setVgap(30);
        gridPane.setHgap(30);

        int j = 0;

        for(int i = 0; i < 3; i++){
            gameFormsArray[i] = new GameForms();
            GridPane.setConstraints(gameFormsArray[i],i,0);
        }
        for(int i = 3; i < 6; i++){
            gameFormsArray[i] = new GameForms();
            GridPane.setConstraints(gameFormsArray[i],i - 3,1);
        }
        for(int i = 6; i < 9; i++){
            gameFormsArray[i] = new GameForms();
            GridPane.setConstraints(gameFormsArray[i],i - 6  ,2);
        }


        this.getChildren().add(gridPane);


        gridPane.getChildren().addAll(gameFormsArray[0],gameFormsArray[1],gameFormsArray[2],
                                      gameFormsArray[3], gameFormsArray[4], gameFormsArray[5],
                                      gameFormsArray[6], gameFormsArray[7], gameFormsArray[8]);

        for(int i = 0; i < gameFormsArray.length; i++){
            int finalI = i;
            gameFormsArray[i].setOnAction(e -> {
                 zug(finalI);

            });
        }

    }

    public void win(){
       for(int i = 0; i < gameFormsArray.length; i++){
           if(gameFormsArray[i].text().equalsIgnoreCase("O") && gameFormsArray[i+1].text().equalsIgnoreCase("O")&&
           gameFormsArray[i+2].text().equalsIgnoreCase("O") || gameFormsArray[0].text().equalsIgnoreCase("O") &&
           gameFormsArray[i+4].text().equalsIgnoreCase("O") && gameFormsArray[i+8].text().equalsIgnoreCase("O")
           || gameFormsArray[2].text().equalsIgnoreCase("O") && gameFormsArray[i+4].text().equalsIgnoreCase("O") &&
                   gameFormsArray[i+6].text().equalsIgnoreCase("O") )
           {
               Alert alert = new Alert(Alert.AlertType.INFORMATION);
               alert.setTitle("Spieler O hat gewonnen");
               alert.setHeaderText("Spieler mit O hat gewonnen");
               alert.showAndWait();
               break;
           } else if(gameFormsArray[i].text().equalsIgnoreCase("x") && gameFormsArray[i+1].text().equalsIgnoreCase("x")&&
                   gameFormsArray[i+2].text().equalsIgnoreCase("x") || gameFormsArray[0].text().equalsIgnoreCase("x") &&
                   gameFormsArray[i+4].text().equalsIgnoreCase("x") && gameFormsArray[i+8].text().equalsIgnoreCase("x")
                   || gameFormsArray[2].text().equalsIgnoreCase("x") && gameFormsArray[i+4].text().equalsIgnoreCase("x") &&
                   gameFormsArray[i+6].text().equalsIgnoreCase("x") ){
               Alert alert = new Alert(Alert.AlertType.INFORMATION);
               alert.setTitle("Spieler X hat gewonnen");
               alert.setHeaderText("Spieler mit X hat gewonnen");
               alert.showAndWait();
               break;
           }
           else{
               continue;
           }
       }

    }

    public void zug(int i){
        if(player){
            gameFormsArray[i].setPrefSize(80,80);
            gameFormsArray[i].setText("X");
        } else {
            gameFormsArray[i].setPrefSize(80,80);
            gameFormsArray[i].setText("O");
        }
        player = !player;
        win();
    }
}
