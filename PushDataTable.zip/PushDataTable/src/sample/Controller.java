package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    public TableView<Product> tableview;

    public TableColumn<Product, String> colName;
    public TableColumn<Product, Double> colPrice;
    public TableColumn<Product, Integer> colQuantity;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // verbindung colName mit product class

        colName.setCellValueFactory(new PropertyValueFactory<>("ProductName"));
        colPrice.setCellValueFactory(new PropertyValueFactory<>("ProductPrice"));
        colQuantity.setCellValueFactory(new PropertyValueFactory<>("ProductQuantity"));
        tableview.setItems(observableList);

    }

    //ObservableList, um Daten in die Tabelle zu pushen

    ObservableList<Product> observableList = FXCollections.observableArrayList(
            new Product("Rumi", 23.1, 1),
            new Product("Nazir", 232.1, 22),
            new Product("Zahir", 2311.1, 12)

    );
}
