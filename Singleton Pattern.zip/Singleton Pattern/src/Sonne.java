public class Sonne {

    private Sonne(){}

    private static Sonne sonne = new Sonne();

    public static Sonne getInstance(){
        return sonne;
    }

    private double dichte = 1.408;

    public double getDichte() {
        return dichte;
    }

    public void setDichte(double dichte){
        if(dichte > 1.408){
            this.dichte = dichte;
        }
    }
}
