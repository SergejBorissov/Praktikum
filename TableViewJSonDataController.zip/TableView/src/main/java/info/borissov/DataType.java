package info.borissov;

/**
 * javaDoc
 *
 * @author Dennis Nolte
 */
public enum DataType {
    CSV,
    XML,
    JSON;
}
