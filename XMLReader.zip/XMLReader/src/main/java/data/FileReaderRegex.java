package data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static javafx.collections.FXCollections.concat;

public class FileReaderRegex {

    public static void main(String[] args) throws Exception{

        FileReader fileReader = new FileReader("/home/sborissov/Schreibtisch/persondata.xml");
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String zeileVersion = bufferedReader.readLine();
        System.out.println(zeileVersion);
        String zeileWurzelement = bufferedReader.readLine();
        System.out.println(zeileWurzelement);
        String zeileNummer = bufferedReader.readLine();
        System.out.println(zeileNummer);
        String zeileName = bufferedReader.readLine();
        System.out.println(zeileName);

        bufferedReader.close();

    }

}

