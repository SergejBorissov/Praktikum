package warenshop;

public class Elektroware extends Ware{

    protected int leistung;
    protected int spannung;
}
