package warenshop;

public class Pizza extends Lebensmittel{
    protected String sorte;


    public Pizza(){
        this.bezeichnung = "Pizza";
        this.artikelnummer = 2221;
        this.preis = 5;
        this.sorte = "Margaritha";
        //this.haltbarkeitsdatum = 21.12.1998;
    }

}
