import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("/home/sborissov/Schreibtisch/Table.json"));
            //scanner = new Scanner(new File("/home/sborissov/Schreibtisch/Table.json"));
            scanner.useDelimiter(":");

            while(scanner.hasNext()){
                System.out.println(scanner.next()+ " ||| ");
            }
            scanner.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}


