package ZeitTracker;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;



public class GrafikTime  extends Application {

    final int W = 700, H = 500;


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage)  {

        // Kreis mit Inhalt noch einbinden
        Circle circle = new Circle(50);
        circle.setStroke(Color.BLACK);
        circle.setFill(Color.WHITE);
        Text number = new Text("Hier steht die Zeiz");
        number.setFont(Font.font("Arial", FontWeight.BOLD, 64));
        StackPane Uhr = new StackPane(circle,number);

        primaryStage.setTitle("Grafik");
        var canvas = new Canvas(W,H);
        var gc = canvas.getGraphicsContext2D();
        drawShapes(gc);


        var root = new Group();
        root.getChildren().add(canvas);
        primaryStage.setScene(new Scene(root));
        primaryStage.show();

    }


    private void drawShapes(GraphicsContext gc) {

        gc.strokeLine(150,450,150,0);
        gc.strokeLine(250,450,250,0);
        gc.strokeLine(0,275,450,275);
        gc.strokeLine(0,160,450,160);


    }


}
