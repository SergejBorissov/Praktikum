package com.ablex.parser.csv;

import com.ablex.model.DataModel;
import com.ablex.parser.DataWriter;

import java.util.List;

public class CSVWriter implements DataWriter
{
    private String fileName;


    @Override
    public String writeData(List<DataModel> dataModelList) {
        return null;
    }
}
