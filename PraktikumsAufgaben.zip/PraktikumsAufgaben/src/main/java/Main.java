/**
 * javaDoc
 *
 * @author gloewen
 */
public class Main {

    public static void main(String[] args) {
        Bank ableXBank = new Bank("ableX");
        Bank ableXBankUnsafe = new Bank("ableX - unsafe");

        for (int i = 0; i < 10; i++) {
            ableXBank.createNewAccount();
            ableXBankUnsafe.createNewAccount();
        }

        doTransfers(ableXBank, true);
        doTransfers(ableXBankUnsafe, false);

        try {
            Thread.sleep(25000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("SAFE **************************");
        ableXBank.printOverview();
        System.out.println("UNSAFE **************************");
        ableXBankUnsafe.printOverview();

    }

    private class BankInherited extends Bank {

        public BankInherited(String name) {
            super(name);
        }
    }

    private static void doTransfers(Bank ableXBank, boolean protectedTransfer) {
        ableXBank.transfer(0,5, 300, protectedTransfer);
        ableXBank.transfer(3,4, 343, protectedTransfer);
        ableXBank.transfer(1,5, 700, protectedTransfer);
        ableXBank.transfer(1,3, 750, protectedTransfer);
        ableXBank.transfer(2,3, 343, protectedTransfer);
        ableXBank.transfer(1,5, 700, protectedTransfer);
        ableXBank.transfer(0,5, 300, protectedTransfer);
        ableXBank.transfer(3,4, 343, protectedTransfer);
        ableXBank.transfer(1,5, 700, protectedTransfer);
        ableXBank.transfer(0,5, 300, protectedTransfer);
        ableXBank.transfer(3,4, 343, protectedTransfer);
        ableXBank.transfer(1,5, 700, protectedTransfer);
        ableXBank.transfer(0,5, 300, protectedTransfer);
        ableXBank.transfer(3,4, 343, protectedTransfer);
        ableXBank.transfer(1,5, 700, protectedTransfer);
        ableXBank.transfer(1,3, 750, protectedTransfer);
        ableXBank.transfer(2,3, 343, protectedTransfer);
        ableXBank.transfer(1,5, 700, protectedTransfer);
        ableXBank.transfer(0,5, 300, protectedTransfer);
        ableXBank.transfer(3,4, 343, protectedTransfer);
        ableXBank.transfer(1,5, 700, protectedTransfer);
        ableXBank.transfer(0,5, 300, protectedTransfer);
        ableXBank.transfer(3,4, 343, protectedTransfer);
        ableXBank.transfer(1,5, 700, protectedTransfer);
    }
}
