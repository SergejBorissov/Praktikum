package tutorialMorpheus;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Tier> tiere = new ArrayList<Tier>();
        tiere.add(new Hund());
        tiere.add(new Elefant());
        tiere.add(new Tier() {
            @Override
            public void macheDichBemerkbar() {
                System.out.println("Auuuuuuuuuuuuu");
            }
        });
        tiere.add(new Tier() {
            @Override
            public void macheDichBemerkbar() {
                System.out.println("echse");
            }
        });
        tiere.add(new Tier() {
            @Override
            public void macheDichBemerkbar() {
                System.out.println("Mia");
            }
        });

        for(int i = 0; i < tiere.size(); i++){
            tiere.get(i).macheDichBemerkbar();
        }
    }
}
