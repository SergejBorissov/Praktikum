import java.sql.*;


public class Datenbank {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/test?useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Berlin";
        String user = "root";
        String password = "";

        try(Connection connection = DriverManager.getConnection(url,user, password)){
            System.out.println("Erfolgreich mit der Datenbank verbunden");

            //Einfügen von Daten
            String query = "INSERT INTO bib(buch_id, vorname, nachname, geburtsdatum) VALUES(12,'Vin','Diesel','1990-04-08')";
            Statement statement = connection.createStatement();
            statement.execute(query);
            statement.close();



            //---------------------------------------------------------------------------
            // ausgeben der Daten
             query = "SELECT * FROM bib ORDER BY buch_id ASC";
             statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            //gibt die Spaltennamen aus
            int columns = resultSet.getMetaData().getColumnCount();
            for(int i = 1; i <= columns; i++)
                System.out.print(String.format("%-15s",resultSet.getMetaData().getColumnLabel(i)));

                System.out.println();
                System.out.println("--------------------------------------------------------------------");

                while(resultSet.next()){
                    for(int j = 1; j <= columns; j++)
                        System.out.print(String.format("%-15s", resultSet.getString(j)));
                    System.out.println();
                }

                resultSet.close();
                statement.close();

        } catch (SQLException exception){
            System.err.println(exception.getMessage());
        }
    }
}
