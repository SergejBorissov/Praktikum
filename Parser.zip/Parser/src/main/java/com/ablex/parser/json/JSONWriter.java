package com.ablex.parser.json;

import com.ablex.model.DataModel;
import com.ablex.parser.DataWriter;

import java.util.List;

public class JSONWriter implements DataWriter
{
    private String fileName;


    @Override
    public String writeData(List<DataModel> dataModelList) {
        return null;
    }
}
