package data;

public class IndexCharStartEndCutter {

    public static void main(String[] args) {

        String name = "<Name>Peter</Name>";
        int indexStart = name.indexOf('>');
        int indexEnd = name.indexOf('/'); // char < berücksichtigen
        System.out.println(indexStart);


            for (int i = indexStart + 1; i < indexEnd - 1; i++) {
                char c = name.charAt(i);
                System.out.print(c);
            }

        }
    }



